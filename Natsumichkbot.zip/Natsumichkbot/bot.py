import logging
from pyrogram import Client, filters
import config
import importlib
import os
import sqlite3
from datetime import datetime

# Configuración de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Desactivar logs de asyncio que no son útiles
logging.getLogger("asyncio").setLevel(logging.CRITICAL)
logging.getLogger("pyrogram").setLevel(logging.INFO)  # Ajusta el nivel según lo que quieras ver

# Crear la aplicación Pyrogram
app = Client("my_bot", api_id=config.API_ID, api_hash=config.API_HASH, bot_token=config.BOT_TOKEN)

# Asegurar que las tablas necesarias existan
def create_tables():
    # Crear tabla de usuarios registrados
    conn = sqlite3.connect('/storage/emulated/0/Download/Natsumichkbot/users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS registered_users (
            id INTEGER PRIMARY KEY,
            username TEXT,
            registration_date TEXT
        )
    ''')
    conn.commit()
    conn.close()

    # Crear tabla de usuarios baneados
    conn = sqlite3.connect('/storage/emulated/0/Download/Natsumichkbot/baneados.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS banned_users (
            id INTEGER PRIMARY KEY,
            username TEXT,
            reason TEXT,
            admin TEXT
        )
    ''')
    conn.commit()
    conn.close()

create_tables()

def load_commands(app):
    commands_dir = os.path.join(os.path.dirname(__file__), "commands")
    logger.info(f"Cargando comandos desde el directorio: {commands_dir}")
    
    for filename in os.listdir(commands_dir):
        if filename.endswith(".py") and filename != "__init__.py":
            module_name = f"commands.{filename[:-3]}"
            try:
                module = importlib.import_module(module_name)
                if hasattr(module, "setup"):
                    module.setup(app)
                    logger.info(f"Comando cargado: {module_name}")
                else:
                    logger.warning(f"No se encontró la función setup en {module_name}")
            except Exception as e:
                logger.error(f"Error al cargar el módulo {module_name}: {e}")

def is_user_registered(user_id):
    conn = sqlite3.connect('/storage/emulated/0/Download/Natsumichkbot/users.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id FROM registered_users WHERE id = ?', (user_id,))
    result = cursor.fetchone()
    conn.close()
    return result is not None

def is_banned(user_id):
    conn = sqlite3.connect('/storage/emulated/0/Download/Natsumichkbot/baneados.db')
    cursor = conn.cursor()
    cursor.execute('SELECT reason FROM banned_users WHERE id = ?', (user_id,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

def is_command_message(message):
    # Verifica si el mensaje contiene un comando en la carpeta commands
    commands_dir = os.path.join(os.path.dirname(__file__), "commands")
    for filename in os.listdir(commands_dir):
        if filename.endswith(".py") and filename != "__init__.py":
            command_name = filename[:-3]
            if message.text and (message.text.startswith(f"/{command_name}") or message.text.startswith(f".{command_name}")):
                return True
    return False

@app.on_message(filters.command(["register", ".register"]))
def register_command(client, message):
    user_id = message.from_user.id
    if is_user_registered(user_id):
        message.reply("⛧ Ya estás registrado en el bot. Puedes usar todos los comandos")
        return

    conn = sqlite3.connect('/storage/emulated/0/Download/Natsumichkbot/users.db')
    cursor = conn.cursor()
    registration_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('INSERT INTO registered_users (id, username, registration_date) VALUES (?, ?, ?)', 
                   (user_id, message.from_user.username, registration_date))
    conn.commit()
    conn.close()

    message.reply("Te Has Registrado Exitosamente. Ahora Puedes Usar Todos Los Comandos De LuxChk")

@app.on_message(filters.create(lambda _, __, message: not is_user_registered(message.from_user.id) and is_command_message(message)))
def handle_unregistered_user(client, message):
    message.reply("⛧ Debes registrarte con el comando /register o .register para usar los comandos")

@app.on_message(filters.create(lambda _, __, message: is_banned(message.from_user.id)))
def handle_banned_user(client, message):
    # No hacer nada si el usuario está baneado
    pass

if __name__ == "__main__":
    load_commands(app)
    app.run()
