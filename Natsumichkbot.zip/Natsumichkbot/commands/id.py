from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

def get_user_rank(user_id: int, seller_file_path: str, viped_file_path: str) -> str:
    try:
        with open(seller_file_path, "r") as file:
            for line in file:
                parts = line.strip().split()
                if parts and str(user_id) == parts[0]:
                    return parts[1] if len(parts) > 1 else "Desconocido"

        with open(viped_file_path, "r") as file:
            for line in file:
                parts = line.strip().split()
                if parts and str(user_id) == parts[0]:
                    return "VIP"
    except Exception as e:
        print(f"Error al acceder a los archivos de rangos: {e}")
    return "Desconocido"

def setup(app: Client):
    @app.on_message(filters.command(["id", ".id"], prefixes=["/", "."]))
    async def get_user_info(client: Client, message: Message):
        if message.reply_to_message:
            user = message.reply_to_message.from_user
        elif len(message.command) > 1:
            user_input = message.command[1]
            try:
                if user_input.isdigit():
                    user = await client.get_users(int(user_input))
                else:
                    user = await client.get_users(user_input)
            except Exception:
                await message.reply(
                    "[[ꕤ]](https://t.me/Luxchks) **Uso Correcto**\n\n"
                    "🜲 **/id 12345678**\n\n"
                    "🜲 **El Comando Se Puede Usar Deslizando Un Mensaje de una persona y Poniendo el comando O Poniendo el comando y El ID o el nombre de usuario de la persona**",
                    quote=True
                )
                return
        else:
            user = message.from_user

        user_id = user.id
        first_name = user.first_name or ""
        last_name = user.last_name or ""
        full_name = f"{first_name} {last_name}".strip()
        profile_url = f"tg://user?id={user_id}"
        group_id = message.chat.id
        owner_profile_url = "https://t.me/Daniels_1906"

        seller_file_path = "/storage/emulated/0/Download/Natsumichkbot/commands/Seller.txt"
        viped_file_path = "/storage/emulated/0/Download/Natsumichkbot/commands/Viped.txt"
        user_rank = get_user_rank(user_id, seller_file_path, viped_file_path)

        response_text = (
    f"[ꕤ](https://t.me/Luxchks) **ID**: `{user_id}`\n"
    f"[ꕤ](https://t.me/Luxchks) **Nombre**: `{full_name}`\n"
    f"[ꕤ](https://t.me/Luxchks) **Rango**: `{user_rank}`\n"
    f"[ꕤ](https://t.me/Luxchks) **Perfil**: [Toca Aquí]({profile_url})\n"
    f"[ꕤ](https://t.me/Luxchks) **GroupID**: `{group_id}`"
)




        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🜲Owner", url=owner_profile_url)]
        ])

        await message.reply(response_text, disable_web_page_preview=True, quote=True, reply_markup=keyboard)