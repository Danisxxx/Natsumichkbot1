import requests
from pyrogram import Client, filters

def setup(client):
    @client.on_message(filters.command("bin"))
    async def cmds(client, message):
        try:
            # Obtener el BIN del mensaje
            input_text = message.text.split(None, 1)
            if len(input_text) < 2:
                return await message.reply("""
[⎔](tg://user?id=) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 ϟ [ BIN INFO ] 
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) **Bin**: **No Valido**?? ✘
[⎔](tg://user?id=) **Formato**: **/bin 123456** ❇️
[⎔](tg://user?id=) **Msg**: **Ingresa un bin Valido** :)
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) **User**: @{}
                """.format(message.from_user.username or 'Unknown'))

            BIN = input_text[1][:6]  # Usar solo los primeros 6 dígitos

            # Validar el BIN
            if len(BIN) != 6 or not BIN.isdigit():
                return await message.reply("""
[⎔](tg://user?id=) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 ϟ [ BIN INFO ] 
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) **Bin**: **No Valido**? ✘
[⎔](tg://user?id=) **Input**: **/bin 458294** ❇️
[⎔](tg://user?id=) **Msg**: **Ingresa un bin Valido** :)
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) User: @{}
                """.format(message.from_user.username or 'Unknown'))

            # Solicitar información del BIN
            response = requests.get(f"https://bins.antipublic.cc/bins/{BIN}")
            req = response.json()

            # Verificar si se obtuvo información del BIN
            if 'bin' not in req:
                await message.reply(f"""
[⎔](tg://user?id=) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 ϟ [ BIN INFO ] 
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) **Bin**: **{BIN}**
[⎔](tg://user?id=) **Info**: **No se encontró información**
[⎔](tg://user?id=) **Bank**: **No disponible**
[⎔](tg://user?id=) **Country**: **No disponible**
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) User: @{message.from_user.username or 'Unknown'}
                """)
            else:
                # Extraer información del BIN
                brand = req.get('brand', 'Información no disponible')
                country = req.get('country', 'Información no disponible')
                country_name = req.get('country_name', 'Información no disponible')
                country_flag = req.get('country_flag', '🚩')
                bank = req.get('bank', 'Información no disponible')

                # Enviar la respuesta
                await message.reply(f"""
[⎔](tg://user?id=) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 ϟ [ BIN INFO ] 
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=)**Bin**: <code>**{BIN}**</code>
[⎔](tg://user?id=)**Info**: <code>**{brand}**</code>
[⎔](tg://user?id=)**Bank**: <code>**{bank}**</code>
[⎔](tg://user?id=)**Country**: <code>**{country_name}**</code> {country_flag}
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) **Status**: ❇️ <code>**Valid Bin**</code>
[⎔](tg://user?id=) **User**: @{message.from_user.username or 'Unknown'}
                """)
        except IndexError:
            await message.reply("""
[⎔](tg://user?id=) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 ϟ [ BIN INFO ] 
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=)**Bin**: **No Valido** ?? ✘
[⎔](tg://user?id=)Formato: /bin 442939 ❇️
[⎔](tg://user?id=)**Msg**: **Ingresa un bin Valido**:)
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) **User**: @{message.from_user.username or 'Unknown'}
            """)
        except ValueError:
            await message.reply("""
[⎔](tg://user?id=) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 ϟ [ BIN INFO ] 
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=**Bin**: **No Valido** ?? ✘
[⎔](tg://user?id=**Formato**: **/bin 448288** ❇️
[⎔](tg://user?id=**Msg**: **Ingresa un bin Valido**:)
[-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=) [-](tg://user?id=)
[⎔](tg://user?id=) **User**: @{message.from_user.username or 'Unknown'}
            """)