from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
import re
import requests
import random
import time
import json
import os

# Rutas de los archivos
VIPED_FILE_PATH = '/storage/emulated/0/Download/Natsumichkbot/commands/Viped.txt'
GROUP_AUTH_FILE_PATH = '/storage/emulated/0/Download/Natsumichkbot/commands/GroupAutorize.txt'
BANNED_BINS = ['654321']
TEMP_DIR = '/storage/emulated/0/Download/Natsumichkbot/temp'

def setup(client):
    """Configura las funciones del cliente para el bot."""
    @client.on_message(filters.regex(r'^[^\w]*gen\b'))
    async def gen_command(client, message):
        """Maneja el comando .gen en diferentes formatos"""
        if message.text.lower().strip() == "gen":
            return  # No responder si el comando es solo "gen" sin prefijo

        input = re.findall(r'\d+', message.text)

        user_rank = get_user_rank(message.from_user.id)
        authorized_groups = get_authorized_groups()

        if message.chat.type == "private":
            if user_rank == "Free user":
                return await message.reply(
                    "⾰ **Lo Siento Para Usar Este Comando Adquiere una membresia**"
                )

        elif message.chat.id not in authorized_groups:
            await message.reply(
                "[⚠️] 𝗛𝗶, 𝐗/𝐜 𝑫𝒂𝒏𝒊𝒆𝒍 𝘆𝗼𝘂 𝗱𝗼𝗻𝘁 𝘀𝗲𝗲𝗺 𝘁𝗼 𝘂𝘀𝗲 𝗺𝗲 \n𝗜𝗳 𝘆𝗼𝘂 𝘄𝗮𝗻𝘁 𝘁𝗼 𝗯𝘂𝘆 𝗺𝗲, 𝗰𝗼𝗻𝘁𝗮𝗰𝘁 𝘁𝗵𝗲 𝗢𝗻𝗲𝗿 \n @Sunblack12"
            )
            return

        if ' ' not in message.text:
            return await message.reply(
                "[⾰](t.me/Natsumichkbot) **Formato Incorrecto Usa /gen 123456**"
            )

        inputms = message.text.split(None, 1)[1]
        raw_bins = re.sub(r'\D', '', inputms.split('|')[0])  # Eliminar caracteres no numéricos
        BINS = raw_bins[:6]  # Asegurarse de que solo se usan los primeros 6 dígitos

        if len(BINS) < 6:
            return await message.reply(
                "[⾰](t.me/Natsumichkbot) **Bins Invalido Proporciona Un Bins Que Tenga Mas De 6 Numeros** ⚠️"
            )

        if BINS in BANNED_BINS:
            return await message.reply(
                "[⾰](t.me/Natsumichkbot) **Bin Banned** ⚠️"
            )

        req = requests.get(f"https://bins.antipublic.cc/bins/{BINS}").json()
        if req.get('status') == 'error':
            return await message.reply(
                "[⾰](t.me/Natsumichkbot) **Bins Invalido Proporciona Un Bins Que Tenga Mas De 6 Numeros** ⚠️"
            )

        brand = req.get('brand', 'Unknown')
        country = req.get('country', 'Unknown')
        country_flag = req.get('country_flag', '🏳️')
        bank = req.get('bank', 'Unknown')
        typea = req.get('type', 'Unknown')

        mes, ano = input[1] if len(input) > 1 else '01', input[2] if len(input) > 2 else '2024'

        tiempoinicio = time.perf_counter()

        ccs = cc_gen(BINS, mes, ano, bank)
        tiempofinal = time.perf_counter()

        if not ccs:
            return await message.reply("[⾰](t.me/Natsumichkbot)**No se pudieron generar tarjetas**")

        text = f"""
[[⽷]](tg://user?id=) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 [𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫 𝐂𝐂]
[- - - - - - - - - - - - - - - - - - - - - - - - -](t.me/Natsumichkbot)
[[⽷]](tg://user?id=) Format - [↯](tg://user?id=) <code>**/gen {BINS}xxxxxx|{mes}|{ano}|{ano}**</code>
[- - - - - - - - - - - - - - - - - - - - - - - - -](t.me/Natsumichkbot)
<code>{ccs[0]}</code>
<code>{ccs[1]}</code>
<code>{ccs[2]}</code>
<code>{ccs[3]}</code>
<code>{ccs[4]}</code>
<code>{ccs[5]}</code>
<code>{ccs[6]}</code>
<code>{ccs[7]}</code>
<code>{ccs[8]}</code>
<code>{ccs[9]}</code>
[- - - - - - - - - - - - - - - - - - - - - - - - -](t.me/Natsumichkbot)
[[⽷]](t.me/Natsumichkbot) Bin ↯ <code>{BINS}</code> | Time - <code>{tiempofinal - tiempoinicio:.3f}s</code>
[[⽷]](t.me/Natsumichkbot) Info ↯ <code>{brand} - {typea}</code>
[[⽷]](t.me/Natsumichkbot) Bank ↯ <code>{bank}</code>
[[⽷]](t.me/Natsumichkbot) Contry ↯ <code>{country}</code> [{country_flag}]
[[⽷]](t.me/Natsumichkbot) Gen by ↯ @{message.from_user.username}↦[<code>{user_rank}</code>]
"""

        if not os.path.exists(TEMP_DIR):
            os.makedirs(TEMP_DIR)

        sent_message = await client.send_message(
            chat_id=message.chat.id,
            text=text,
            reply_to_message_id=message.id if message.id else None,
            reply_markup=generate_inline_keyboard(BINS, mes, ano, bank)
        )

        message_data = {
            'chat_id': message.chat.id,
            'message_id': sent_message.id,
            'bins': BINS,
            'mes': mes,
            'ano': ano,
            'brand': brand,
            'country': country,
            'country_flag': country_flag,
            'bank': bank,
            'typea': typea,
            'username': message.from_user.username,
            'user_rank': user_rank,
            'timestamp': time.perf_counter()
        }

        with open(f'{TEMP_DIR}/gen_message_{sent_message.id}.json', 'w') as f:
            json.dump(message_data, f)

    @client.on_callback_query(filters.regex(r"regen_(\d{6})"))
    async def regenerate_cards(client, callback_query: CallbackQuery):
        """Regenera tarjetas cuando se presiona el botón"""
        bin_prefix = callback_query.data.split("_")[1]
        file_path = f'{TEMP_DIR}/gen_message_{callback_query.message.id}.json'
        
        if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
            await callback_query.message.edit_text("Error: no se encontraron datos para regenerar.")
            return

        with open(file_path, 'r') as f:
            message_data = json.load(f)

        bin_prefix = message_data['bins']
        mes = message_data['mes']
        ano = message_data['ano']
        bank = message_data['bank']
        brand = message_data['brand']
        country = message_data['country']
        country_flag = message_data['country_flag']
        typea = message_data['typea']
        username = message_data['username']
        user_rank = message_data['user_rank']

        ccs = cc_gen(bin_prefix, mes, ano, bank)

        text = f"""
[[⽷]](tg://user?id=) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 [𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫 𝐂𝐂]
[- - - - - - - - - - - - - - - - - - - - - - - - -](t.me/Natsumichkbot)
[[⽷]](tg://user?id=) Format - [↯](tg://user?id=) <code>**/gen {bin_prefix}xxxxxx|{mes}|{ano}|{ano}**</code>
[- - - - - - - - - - - - - - - - - - - - - - - - -](t.me/Natsumichkbot)
<code>{ccs[0]}</code>
<code>{ccs[1]}</code>
<code>{ccs[2]}</code>
<code>{ccs[3]}</code>
<code>{ccs[4]}</code>
<code>{ccs[5]}</code>
<code>{ccs[6]}</code>
<code>{ccs[7]}</code>
<code>{ccs[8]}</code>
<code>{ccs[9]}</code>
[- - - - - - - - - - - - - - - - - - - - - - - - -](t.me/Natsumichkbot)
[[⽷]](t.me/Natsumichkbot) Bin ↯ <code>{bin_prefix}</code> | Time - <code>{time.perf_counter() - float(message_data.get('timestamp', time.perf_counter())):.3f}s</code>
[[⽷]](t.me/Natsumichkbot) Info ↯ <code>{brand} - {typea}</code>
[[⽷]](t.me/Natsumichkbot) Bank ↯ <code>{bank}</code>
[[⽷]](t.me/Natsumichkbot) Contry ↯ <code>{country}</code> [{country_flag}]
[[⽷]](t.me/Natsumichkbot) Gen by ↯ @{username}↦[<code>{user_rank}</code>]
"""

        await callback_query.message.edit_text(text, reply_markup=generate_inline_keyboard(bin_prefix, mes, ano, bank))

def generate_inline_keyboard(bin_prefix, mes, ano, bank):
    """Genera el teclado inline con el botón de regenerar"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Regenerar", callback_data=f"regen_{bin_prefix}")]
    ])

def get_user_rank(user_id):
    """Obtiene el rango del usuario basado en su ID"""
    try:
        with open(VIPED_FILE_PATH, 'r') as file:
            vip_ids = file.read().splitlines()
        for line in vip_ids:
            if str(user_id) in line:
                return "VIP"
        return "Free user"
    except FileNotFoundError:
        return "Free user"

def get_authorized_groups():
    """Obtiene la lista de grupos autorizados"""
    try:
        with open(GROUP_AUTH_FILE_PATH, 'r') as file:
            return [int(line.strip()) for line in file.readlines()]
    except FileNotFoundError:
        return []

def cc_gen(bin_prefix, mes, ano, bank):
    """Genera un número de tarjeta con el BIN proporcionado"""
    cvv_length = 4 if "AMERICAN EXPRESS" in bank.upper() else 3

    def generate_card_number(bin_prefix):
        """Genera el número de tarjeta"""
        card_number = bin_prefix + ''.join(str(random.randint(0, 9)) for _ in range(10))
        return card_number[:16]  # Asegurarse de que la tarjeta tenga 16 dígitos

    def generate_cvv():
        """Genera un CVV"""
        return ''.join(str(random.randint(0, 9)) for _ in range(cvv_length))

    card_numbers = [generate_card_number(bin_prefix) + '|' + mes + '|' + ano + '|' + generate_cvv() for _ in range(10)]
    return card_numbers
