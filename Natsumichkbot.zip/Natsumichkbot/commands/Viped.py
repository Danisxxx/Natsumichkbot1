import os
import re
import schedule
import asyncio
from datetime import datetime, timedelta
from pyrogram import Client, filters as PyrogramFilters
from database import save_key, get_key, claim_key, log_error

VIPED_FILE = "/storage/emulated/0/Download/Natsumichkbot/commands/Viped.txt"
SELLER_FILE = "/storage/emulated/0/Download/Natsumichkbot/commands/Seller.txt"
UPDATE_INTERVAL = 4  # Intervalo de actualización en segundos, ajustado para pasar más rápido
order_counter = 1  # Variable global para contar las órdenes

def load_sellers():
    """Carga los IDs de administradores desde el archivo."""
    if not os.path.exists(SELLER_FILE):
        return set()
    with open(SELLER_FILE, 'r') as f:
        sellers = set(line.split()[0].strip() for line in f if line.strip())  # Solo IDs, ignorar líneas vacías
    return sellers

def load_viped():
    """Carga los datos de usuarios VIP desde el archivo."""
    if not os.path.exists(VIPED_FILE):
        return {}
    viped = {}
    with open(VIPED_FILE, 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) == 5:  # Formato con rango y expiración
                user_id, days, credits, expiration_str, rank = parts
                expiration_time = parse_expiration(expiration_str)
            elif len(parts) == 4:  # Formato sin expiración específica
                user_id, days, credits, rank = parts
                expiration_time = calculate_expiration(int(days))
            else:
                continue
            viped[user_id] = {
                'days': int(days),
                'credits': int(credits),
                'rank': rank,
                'expiration_time': expiration_time
            }
    return viped

def parse_expiration(expiration_str):
    """Parses a formatted expiration string into a datetime object."""
    days, hours, minutes, seconds = map(int, re.findall(r'(\d+)', expiration_str))
    return datetime.now() + timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)

def save_viped(viped):
    """Guarda los datos de usuarios VIP en el archivo."""
    with open(VIPED_FILE, 'w') as f:
        for user_id, data in viped.items():
            expiration_str = format_expiration(data['expiration_time'])
            f.write(f"{user_id} {data['days']} {data['credits']} {expiration_str} {data['rank']}\n")

def calculate_expiration(days):
    """Calcula el tiempo de expiración basado en los días."""
    return datetime.now() + timedelta(days=days)

def format_expiration(expiration_time):
    """Formatea el tiempo restante hasta la expiración en tiempo real."""
    remaining = expiration_time - datetime.now()
    if remaining.total_seconds() <= 0:
        return "Expired"
    days, seconds = remaining.days, remaining.seconds
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    return f"{days}d-{hours}h-{minutes}m-{seconds}s"

def update_viped_real_time():
    """Actualiza el archivo Viped.txt en tiempo real."""
    try:
        viped = load_viped()
        current_time = datetime.now()
        expired_users = [user_id for user_id, data in viped.items() if current_time >= data['expiration_time']]
        for user_id in expired_users:
            del viped[user_id]
        save_viped(viped)
    except Exception as e:
        log_error(str(e))

def setup(app: Client):
    @app.on_message(PyrogramFilters.command("Vip"))
    async def viped(client, message):
        global order_counter
        try:
            sellers = load_sellers()
            if str(message.from_user.id) not in sellers:
                await message.reply(
                    "[ꕤ] SECURITY SIRELLE CHK\n\n"
                    "**No Tienes Permiso Para Usar este Comando Solo Los Rango Seller Pueden**\n"
                    " - - - - - - - - - - - - - - - - - - - - - - - -\n"
                    "Más información: [SirelleChk](https://t.me/SirelleChk)"
                )
                return

            parts = message.text.split()
            if len(parts) < 4:
                await message.reply("**Uso incorrecto del comando. Uso: /Vip ID Días Créditos**")
                return

            user_id, days, credits = parts[1], int(parts[2]), int(parts[3])
            viped = load_viped()

            if user_id in viped:
                if days == 0 and credits == 0:
                    del viped[user_id]
                    await message.reply(f"**El ID {user_id} ha sido eliminado del archivo VIP**")
                else:
                    viped[user_id]['days'] += days
                    viped[user_id]['credits'] += credits
                    # Recalcula la expiración con los días adicionales
                    viped[user_id]['expiration_time'] = calculate_expiration(viped[user_id]['days'])
            else:
                if days == 0 and credits == 0:
                    await message.reply("**No se puede eliminar un usuario que no existe en el archivo VIP**")
                    return
                viped[user_id] = {
                    'days': days,
                    'credits': credits,
                    'rank': "VIP",
                    'expiration_time': calculate_expiration(days)
                }

            save_viped(viped)

            # Obtener el nombre de usuario del usuario objetivo
            try:
                user = await client.get_users(user_id)
                user_username = user.username if user.username else user.first_name
            except Exception as e:
                user_username = "Unknown"

            # Mensaje al usuario confirmando la asignación de días y créditos
            admin_name = message.from_user.first_name
            admin_username = message.from_user.username
            thank_you_message = (
                f"[✿](https://t.me/Natsumichk) 𝙊𝙍𝘿𝙀𝙉 𝘾𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙏𝙄𝙊𝙉 #{order_counter}\n"
                "[- - - - - - - - - - - - - - - - - - - - - - - -](https://t.me/Natsumichk)\n"
                f" [✿](https://t.me/Natsumichk)⤑User ID: <code>{user_id}</code>\n"
                f" [✿](https://t.me/Natsumichk)⤑Dias contratados: <code>{days}</code>\n"
                f" [✿](https://t.me/Natsumichk)⤑Creditos: <code>{credits}</code>\n"
                " [✿](https://t.me/Natsumichk)⤑Rango: <code>VIP</code>\n"
                "[- - - - - - - - - - - - - - - - - - - - - - - -](https://t.me/SirelleChk)\n"
                f"**Bienvenido @{user_username}, tú ID [<code>{user_id}</code>] ha sido promovida en nuestro CHK. \n"
                "¡Gracias por confiar en nosotros!**\n"
                "[- - - - - - - - - - - - - - - - - - - - - - - -](https://t.me/Natsumichk)\n"
                f" [✿](https://t.me/Natsumichk) Seller: @{admin_username}\n"
                " [✿](https://t.me/Natsumichk) Referencias: [Click Aquí](https://t.me/Natsumichk)\n"
                " [✿](https://t.me/Natsumichk) Terminos y condiciones [click aquí]"
            )
            order_counter += 1  # Incrementar el contador de órdenes

            # Enviar mensaje al usuario con la confirmación
            try:
                await client.send_message(chat_id=user_id, text=thank_you_message)
            except Exception as e:
                log_error(f"Error al enviar el mensaje al usuario {user_id}: {str(e)}")

            # Notificar al administrador que ejecuta el comando
            expiration_time = calculate_expiration(days)
            admin_message = f"""
**La ID <code>{user_id}</code> ha sido promovida al plan VIP**!
**Días**: <code>**{days}**</code>
**Créditos**: <code>**{credits}**</code>
**Expiración**: <code>**{format_expiration(expiration_time)}**</code>
            """
            # Enviar el mensaje al admin que ejecuta el comando
            await message.reply(admin_message)

        except Exception as e:
            log_error(str(e))
            await message.reply("**Se produjo un error al procesar el comando. Por favor, intente nuevamente más tarde.**")

    # Configura la tarea de actualización en tiempo real con `schedule`
    schedule.every(UPDATE_INTERVAL).seconds.do(update_viped_real_time)

    # Ejecutar la tarea de actualización en tiempo real en segundo plano
    async def run_scheduler():
        while True:
            schedule.run_pending()
            await asyncio.sleep(1)  # Ajuste para permitir la ejecución de otras tareas

    app.loop.create_task(run_scheduler())
