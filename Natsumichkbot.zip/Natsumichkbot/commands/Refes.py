from pyrogram import Client, filters
import asyncio

def get_allowed_ids(file_path):
    allowed_ids = set()
    try:
        with open(file_path, "r") as file:
            for line in file:
                parts = line.strip().split()
                if parts:
                    allowed_ids.add(parts[0])
    except Exception as e:
        print(f"Error al acceder al archivo de IDs: {e}")
    return allowed_ids

def is_user_registered(user_id, allowed_ids):
    return user_id in allowed_ids

def setup(app: Client):
    @app.on_message(filters.regex(r'^[^\s]*refes') & filters.reply)
    async def refes(client, message):
        if not message.from_user or not message.from_user.id:
            return
        # Resto de la lógica para mensajes válidos

        try:
            seller_file_path = "/storage/emulated/0/Download/Natsumichkbot/commands/Seller.txt"

            allowed_ids = get_allowed_ids(seller_file_path)

            user_id = str(message.from_user.id)
            if not is_user_registered(user_id, allowed_ids):
                return  
                
            replied_message = message.reply_to_message
            if not replied_message or not replied_message.photo:
                return await message.reply(
                    "[⾰](t.me/Natsumichkbot)**Natsumi Security CHK**\n\n**Por favor, responde a un mensaje con una foto**\n", 
                    disable_web_page_preview=True
                )

            original_user_id = str(replied_message.from_user.id) 
            user = replied_message.from_user.username or replied_message.from_user.first_name
            caption_message = replied_message.caption or "None"

            if len(caption_message) > 40:
                return await message.reply(
                    "[⾰](t.me/Natsumichkbot) **Natsumi Security CHK** \n\n**Esta Referencia Es Inválida**\n"
                    "**Puede Ser Porque Es Un Mensaje Sin Foto O Una Foto con un Título De Más de 40 Letras**\n", 
                    disable_web_page_preview=True
                )

            caption = f"""
[[⽷]](t.me/Natsumichkbot) 𝗡𝗮𝘁𝘀𝘂𝗺𝗶 𝗖𝗛𝗞 [**𝘙𝘌𝘍𝘌𝘚**]
[- - - - - - - - - - - - - - - - - - - - - - - -](t.me/Natsumichkbot)
[[⽷]](t.me/Natsumichkbot) **UserID**: [<code>{original_user_id}</code>]
[[⽷]](t.me/Natsumichkbot) **Username**: @{user}
[[⽷]](t.me/Natsumichkbot) **Message**: **{caption_message}**
[- - - - - - - - - - - - - - - - - - - - - - - -](t.me/Natsumichkbot)
"""

            chat_id = "-1002211559089" 

            async def send_photo_with_retries():
                retries = 3
                for _ in range(retries):
                    try:
                        print(f"Enviando foto a chat_id: {chat_id} con file_id: {replied_message.photo.file_id}")
                        await client.send_photo(
                            chat_id=chat_id,
                            photo=replied_message.photo.file_id,
                            caption=caption
                        )
                        await message.reply(
                            "[⾰](t.me/Natsumichkbot) 𝙏𝙝𝙖𝙣𝙠 𝙮𝙤𝙪 𝙛𝙤𝙧 𝙮𝙤𝙪𝙧 𝙧𝙚𝙛𝙚𝙧𝙚𝙣𝙘𝙚. 𝙄𝙩 𝙝𝙖𝙨 𝙗𝙚𝙚𝙣 𝙨𝙚𝙣𝙩 𝙨𝙪𝙘𝙘𝙚𝙨𝙨𝙛𝙪𝙡𝙡𝙮", 
                            disable_web_page_preview=True
                        )
                        break  
                    except Exception as e:
                        print(f"Error al enviar la foto: {e}")  
                        await asyncio.sleep(2) 

            await send_photo_with_retries()

        except Exception as e:
            print(f"Error en el comando .refes: {e}")  

    @app.on_message(filters.regex(r'^[^\s]*refes') & ~filters.reply)
    async def refes_invalid_usage(client, message):
        if not message.from_user:
            return  

        try:
            user_id = str(message.from_user.id)
            seller_file_path = "/storage/emulated/0/Download/Natsumichkbot/commands/Seller.txt"
            allowed_ids = get_allowed_ids(seller_file_path)

            if is_user_registered(user_id, allowed_ids):
                await message.reply(
                    "[⾰](t.me/Natsumichkbot) **Natsumi Security CHK** \n\n**Para Usar Este Comando Usa /refes Respondiendo A una Imagen**\n", 
                    disable_web_page_preview=True
                )
        except Exception as e:
            print(f"Error en el comando .refes invalid usage: {e}")  

    @app.on_message(filters.create(lambda _, __, message: (message.from_user and not is_user_registered(str(message.from_user.id), get_allowed_ids("/storage/emulated/0/Download/Natsumichkbot/commands/Seller.txt")))))
    async def refes_command(client, message): 
        pass
