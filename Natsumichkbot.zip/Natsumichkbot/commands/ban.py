import logging
from pyrogram import Client, filters
import sqlite3
import time

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

def is_admin(user_id):
    admins_file = '/storage/emulated/0/Download/Natsumichkbot/commands/Seller.txt'
    try:
        with open(admins_file, 'r') as f:
            admins = [line.strip().split(maxsplit=1) for line in f if line.strip()]
        logger.debug(f"Admins leídos: {admins}")
    except FileNotFoundError:
        logger.error(f"Archivo no encontrado: {admins_file}")
        return False
    return any(str(user_id) == admin_id for admin_id, _ in admins)

def is_banned(user_id):
    conn = sqlite3.connect('/storage/emulated/0/Download/Natsumichkbot/baneados.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id FROM banned_users WHERE id = ?', (user_id,))
    result = cursor.fetchone()
    conn.close()
    return result is not None

def create_tables():
    conn = sqlite3.connect('/storage/emulated/0/Download/Natsumichkbot/baneados.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS banned_users (
            id INTEGER PRIMARY KEY,
            username TEXT,
            reason TEXT,
            admin TEXT
        )
    ''')
    conn.commit()
    conn.close()

create_tables()

def execute_db_query(query, params=()):
    retries = 5
    while retries > 0:
        try:
            conn = sqlite3.connect('/storage/emulated/0/Download/Natsumichkbot/baneados.db')
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
            conn.close()
            return cursor
        except sqlite3.OperationalError as e:
            if "locked" in str(e):
                retries -= 1
                time.sleep(0.5)
            else:
                raise e

def setup(app: Client):
    command_prefixes = ["/", ".", "?", "!", "~", "-", "@", "#", "€", "_", "&", "+", "(", ")", "*", "©", ":", ";", "`", "|", "•", "√", "π", "÷", "×", "%", "§", "∆", "£", "¥", "$", "¢", "^", "°", "=", "{", "}"]


    @app.on_message(filters.command("ban", prefixes=command_prefixes))
    def ban_command(client, message):
        if not is_admin(message.from_user.id):
            message.reply("[⽷](tg://user?id={user_id}) **Lo Siento No Estas Autorizado para usar este comando** ❌")
            return

        try:
            args = message.text.split(maxsplit=2)
            if len(args) < 3:
                message.reply("[[⽷]](tg://user?id={user_id}) **ID Invalida Proporciona Una ID Valida**")
                return

            user_id = int(args[1])
            reason = args[2]

            if is_banned(user_id):
                message.reply(f"[⽷](tg://user?id={user_id}) **Usuario** [<code>{user_id}</code>] **Ya está baneado** ❌")
                return

            execute_db_query('INSERT INTO banned_users (id, username, reason, admin) VALUES (?, ?, ?, ?)',
                             (user_id, '', reason, message.from_user.username))

            message.reply(f"[[⽷]](tg://user?id={user_id}) **Usuario** [<code>{user_id}</code>] **ha sido Baneado Razón**: [<code>**{reason}**</code>]")
        except Exception as e:
            logger.error(f"**Error al banear al usuario**: {e}")
            message.reply("[[⽷]](tg://user?id={user_id}) **Error al procesar el baneo**")

    @app.on_message(filters.command("unban", prefixes=command_prefixes))
    def unban_command(client, message):
        if not is_admin(message.from_user.id):
            message.reply("[[⽷]](tg://user?id={user_id}) **Lo Siento No Estas Autorizado para usar este comando** ❌**")
            return

        try:
            args = message.text.split(maxsplit=1)
            if len(args) < 2:
                message.reply("[[⽷]](tg://user?id={user_id}) **ID Invalida Proporciona Una ID Valida**")
                return

            user_id = int(args[1])

            execute_db_query('DELETE FROM banned_users WHERE id = ?', (user_id,))

            message.reply(f"[[⽷]](tg://user?id={user_id}) **Usuario** [<code>{user_id}</code>] **ha sido desbaneado**")
        except Exception as e:
            logger.error(f"Error al desbanear al usuario: {e}")
            message.reply("[[⽷]](tg://user?id={user_id}) Error al procesar el desbaneo")

    @app.on_message(filters.create(lambda _, __, message: is_banned(message.from_user.id)))
    def handle_banned_user(client, message):
        message.reply("[[⽷]](tg://user?id={user_id}) **Estás baneado y no puedes usar el bot**")
