import os
import requests
from pyrogram import Client, filters

# Configuración de país y emojis
country_data = {
    'mx': {'country': 'México', 'flag': '🇲🇽', 'locale': 'es'},
    'us': {'country': 'Estados Unidos', 'flag': '🇺🇸', 'locale': 'en'},
    'ca': {'country': 'Canadá', 'flag': '🇨🇦', 'locale': 'en'},
    've': {'country': 'Venezuela', 'flag': '🇻🇪', 'locale': 'es'},
    'col': {'country': 'Colombia', 'flag': '🇨🇴', 'locale': 'es'},
    'br': {'country': 'Brasil', 'flag': '🇧🇷', 'locale': 'pt'},
    'in': {'country': 'India', 'flag': '🇮🇳', 'locale': 'en'},
    'ec': {'country': 'Ecuador', 'flag': '🇪🇨', 'locale': 'es'},
    'ja': {'country': 'Japón', 'flag': '🇯🇵', 'locale': 'ja'}
}

def get_random_address(country_code):
    if country_code not in country_data:
        return None

    locale = country_data[country_code]['locale']
    response = requests.get(f'https://randomuser.me/api/?nat={country_code}&inc=name,location,phone&results=1')
    if response.status_code != 200:
        return None

    data = response.json()['results'][0]
    name = f"{data['name']['first']} {data['name']['last']}"
    address = {
        'name': name,
        'street': data['location']['street']['name'],
        'city': data['location']['city'],
        'state': data['location']['state'],
        'postal_code': data['location']['postcode'],
        'phone': data['phone'],
        'country': country_data[country_code]['country'],
        'flag': country_data[country_code]['flag']
    }
    return address

def get_temp_email():
    response = requests.get('https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1')
    if response.status_code == 200:
        return response.json()[0]
    return None

def setup(app):
    @app.on_message(filters.command(['fake', '.fake']))
    async def fake_address(client, message):
        command = message.text.split()
        if len(command) != 2:
            await message.reply("🜲 Security LuxCheker 🜲\n\n🜲 Uso Correcto /fake ca,mx,ve,us,ja\n🜲 Cualquier Usuario")
            return

        country_code = command[1]
        address = get_random_address(country_code)
        email = get_temp_email()

        if not address or not email:
            await message.reply("Código de país no soportado o error en la generación de la dirección o correo.")
            return

        user_id = message.from_user.id
        email_link = f"[click aquí](https://www.fakemailgenerator.com/#/teleworm.us/{email.split('@')[0]}/s)"
        tg_link = f"tg://user?id={user_id}"
        hidden_link = f"tg://t.me-{user_id}"

        response = f"""
𝑭𝒂𝒌𝒆 𝑨𝒅𝒓𝒆𝒔𝒔 | [𝐒𝐢𝐫𝐞𝐥𝐥𝐞]
[-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link})
[[ꕤ]](tg://user?id={user_id}) Name: <code>{address['name']}</code>
[[ꕤ]](tg://user?id={user_id}) País: <code>{address['country']}</code> {address['flag']}
[[ꕤ]](tg://user?id={user_id}) Street: <code>{address['street']}</code>
[[ꕤ]](tg://user?id={user_id}) City: <code>{address['city']}</code>
[[ꕤ]](tg://user?id={user_id}) State: <code>{address['state']}</code>
[[ꕤ]](tg://user?id={user_id}) Zip: <code>{address['postal_code']}</code>
[[ꕤ]](tg://user?id={user_id}) Phone: <code>{address['phone']}</code>
[[ꕤ]](tg://user?id={user_id}) Email: <code>{email}</code> ({email_link})
[[ꕤ]](tg://user?id={user_id}) Generate: @{message.from_user.username}
[-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link}) [-]({tg_link})\n
        """

        await message.reply(response)

# Código de ejemplo para inicializar la aplicación (no incluir en la implementación final)
# app = Client("my_account")
# setup(app)
# app.run()
